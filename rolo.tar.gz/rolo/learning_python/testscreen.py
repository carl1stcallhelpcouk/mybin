#!/usr/bin/env python3
import subprocess
 
cmd = ['xrandr']
cmd2 = ['grep', '*']
p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
p2 = subprocess.Popen(cmd2, stdin=p.stdout, stdout=subprocess.PIPE)
p.stdout.close()
 
resolution_string, junk = p2.communicate()
resolution = resolution_string.split()[0]
print ('resolution = ',resolution)

width, height = resolution.split(b'x')
print (int(width),"x",int(height))